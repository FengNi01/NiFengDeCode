<?php /*a:1:{s:43:"/www/wwwroot/dexstore/view/index/index.html";i:1651470133;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
<meta charset="utf-8">
<title>登录&注册Gallons通行证</title>
<link rel="stylesheet" href="/static/css/style.css">
</head>

<body>
    <div class="content">
        <div class="form sign-in">
            <h2>欢迎回来</h2>
            <label>
                <span>邮箱</span>
                <input type="email" />
            </label>
            <label>
                <span>密码</span>
                <input type="password" />
            </label>
            <p class="forgot-pass"><a href="javascript:">忘记密码？</a></p>
            <button type="button" class="submit">登 录</button>
            <button type="button" class="fb-btn">使用 <span>QQ</span> 帐号登录</button>
        </div>
        <div class="sub-cont">
            <div class="img">
                <div class="img__text m--up">
                    <h2>还未注册？</h2>
                    <p>立即注册，发现大量机会！</p>
                </div>
                <div class="img__text m--in">
                    <h2>已有帐号？</h2>
                    <p>有帐号就登录吧，好久不见了！</p>
                </div>
                <div class="img__btn">
                    <span class="m--up">注 册</span>
                    <span class="m--in">登 录</span>
                </div>
            </div>
            <div class="form sign-up">
                <h2>立即注册</h2>
                <label>
                    <span>用户名</span>
                    <input type="text" />
                </label>
                <label>
                    <span>邮箱</span>
                    <input type="email" />
                </label>
                <label>
                    <span>密码</span>
                    <input type="password" />
                </label>
                <button type="button" class="reg">注 册</button>
                <button type="button" class="fb-btn">使用 <span>QQ</span> 帐号注册</button>
            </div>
        </div>
    </div>

    <script src="/static/js/script.js"></script>
	
	<div style="text-align:center;">
<p>官网<a href="http://www.dexstore.top/" target="_blank">Gallons</a></p>
</div>
</body>

</html>