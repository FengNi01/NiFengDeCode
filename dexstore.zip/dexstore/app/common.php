<?php
// 应用公共文件
use PHPMailer\PHPMailer\PHPMailer;

function get_account(){
    // 自动生成随机用户名
        $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $username = "";
        for ($i = 0; $i < 6; $i++) {
            $username .= $chars[mt_rand(0, strlen($chars))];
        }

        return strtoupper(base_convert(time() - 1420070400, 10, 36)) . $username;
}

function mailer($title, $content,$tomail){
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->CharSet = "UTF-8";
    $mail->Host = "smtp.yunyou.top";
    $mail->SMTPAuth = true;
    $mail->Username = "nifeng@hlunn.com";
    $mail->Password = "叫爸爸就给密码";
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->setFrom("nifeng@hlunn.com", "系统");
    $mail->addAddress($tomail, '用户');
    $mail->addReplyTo("3200180046@qq.com", "管理员");
    $mail->Subject = $title;
    $mail->isHTML(true);
    $mail->Body = $content;
    if (!$mail->send()) {
        $rs=[
            'code' => 200,
            'msg' => "验证码发送失败".$mail->ErrorInfo
        ];
        return $rs;
    } else {
        $rs=[
            'code' => 200,
            'msg' => '发送成功'
        ];
        return $rs;
    }
}

function creat_code(){
    $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        $pwd = '';
        for($i=0;$i<6;$i++){
            $rand = rand(0,strlen($str)-1);
            $pwd .= $str[$rand];
        }
        return $pwd;

}


//获取真实的IP地址
function getip(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
	$cip = $_SERVER['HTTP_CLIENT_IP'];
	}
	else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
	$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	else if(!empty($_SERVER["REMOTE_ADDR"])){
	$cip = $_SERVER["REMOTE_ADDR"];
	}else{
	$cip = '';
	}
	preg_match("/[\d\.]{7,15}/", $cip, $cips);
	$cip = isset($cips[0]) ? $cips[0] : 'unknown';
	unset($cips);
	return $cip;
}