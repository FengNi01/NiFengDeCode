<?php 

namespace app\controller;
use app\model\FuxiTot;

class Fuxi{
    public function add(){
        
        $db = new FuxiTot();
        $db->add(getip());
    
    }
    
    public function version(){
        $rs = [
            'url' => 'https://jq.qq.com/?_wv=1027&k=9Zset4kG',
            'version' => 1.0,
            'content' => '优化细节'
            ];
        return json($rs);
    }
    
    public function announce(){
        $rs = [
            'content' => '本应用完全免费，欢迎加群交流348350498用爱发电很不容易喜欢的话可以捐助开发者'
            ];
        return json($rs);
    }
}