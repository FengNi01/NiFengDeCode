<?php
namespace app\controller;
use think\facade\View;
use app\BaseController;

class Index
{
    public function index()
    {
        return View::fetch('index');
    }
}
