<?php
namespace app\model;
use think\Model;
class FuxiTot extends Model
{
    protected $schema = [
        'id' => 'bigint',
        'ip' => 'varchar',
        'time' => '	bigint'
    ];
    public function add($ip){
        $user = new FuxiTot;
        $user->save([
            'ip'  =>  $ip,
            'time' => time()
        ]);

    }

}