<?php
namespace app\model;
use think\Model;
class UserInfo extends Model
{
    protected $schema = [
        'id' => 'int',
        'name' => 'varchar',
        'power' => 'int',
        'head' => 'varchar',
        'ac_time' => 'int',
        'account' => 'varchar',
        'exp' => 'int',
        'device' => 'varchar',
        'pass' => 'varchar',
        'gold' => 'bigint',
        'mail' => 'varchar'
    ];
    public function reg($mail,$name,$device,$pass,$account,$head){
        $user = new UserInfo;
        $user->save([
            'name'  =>  $name,
            'mail' =>  $mail,
            'device' => $device,
            'pass' => $pass,
            'account' => $account,
            'head' => $head,
            'exp' => 0,
            'power' => 0,
            'gold' => 0,
            'ac_time' => time()
        ]);

    }

}