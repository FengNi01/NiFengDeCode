document.querySelector('.img__btn').addEventListener('click', function() {
    document.querySelector('.content').classList.toggle('s--signup')
})
document.querySelector('.reg').addEventListener('click',function() {
    document.querySelector('.reg').style.backgroundColor='red'
})
